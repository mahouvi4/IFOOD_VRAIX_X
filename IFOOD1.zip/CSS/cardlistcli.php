<?php
require_once('../LESFONCTIONS/fonctions.php');
$vlox=afficherproduit();

?>

<!DOCTYPE html>
<html>
    <head>
        <title>CATALOG</title>
        <meta charset="UTF-8">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css"
         rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" 
        crossorigin="anonymous">
        <style>
   
       
   .card{
          margin-top: 100px;
          width: 200px;
          height: 130px;
          object-fit: cover;
    box-shadow: 0 2px 12px #000000;
      }

      
        </style>
    </head>
<body>
   <div class=container>
      <div class="card">
         <div class="row">
             <p>dhdhdhdhdhd</p>
         </div>
      </div>
   </div>
</body>

</html>