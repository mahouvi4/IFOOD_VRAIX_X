<!DOCTYPE html>
<html lang="en">
    <head>
        <title>ICONE ACEUILLE</title>
        <meta charset="UTF -8">
        <!--<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet">-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha256-eZrrJcwDc/3uDhsdt61sL2oOBY362qM3lon1gyExkL0=" crossorigin="anonymous" />
                <link rel="stylesheet" type="text/css" href="stal.css">
                <style>
                   ul li label{
                    left:-500px;
                    top:350px
                   }
                </style>
       </head>
      <body>
          <ul>
              <li>
                  <label>
                      <input type="checkbox" name="">
                      <div class="icon"><i class="fa fa-heart" aria-hidden="true"></i></div>
                  </label>
              </li>

              <li>
                  <label>
                      <input type="checkbox" name="">
                      <div class="icon"><i class="fa fa-globe" aria-hidden="true"></i></div>
                  </label>
              </li>

              <li>
                  <label>
                      <input type="checkbox" name="">
                      <div class="icon"><i class="fa fa-gift" aria-hidden="true"></i></div>
                  </label>
              </li>

              <li>
                  <label>
                      <input type="checkbox" name="">
                      <div class="icon"><i class="fa fa-glass" aria-hidden="true"></i></div>
                  </label>
              </li>

              <li>
                  <label>
                      <input type="checkbox" name="">
                      <div class="icon"><i class="fa fa-graduation-cap" aria-hidden="true"></i></div>
                  </label>
              </li>

               
              <li>
                  <label>
                      <input type="checkbox" name="">
                      <div class="icon"><i class="fa fa-graduation-cap" aria-hidden="true"></i></div>
                  </label>
              </li>

              

          </ul>
      </body>
      </html>