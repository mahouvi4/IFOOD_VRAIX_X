<!DOCTYPE html>
<html lang="en">
    <head>
        <title>PROFIL UTILISATEUR</title>
        <meta charset="UTF -8">
        <link rel="stylesheet" type="text/css" href="stymax.css">
       
    </head>
    <body>
      <div class="container">
            <div class="box">
                <span></span>
                <div class="content">
                  <h2>card one</h2>
                  <p>salut!! je ne suis pas content de vous pour ce que vous m'aviez fait !!</p>
                  <a href="#" >Read more</a>
              </div>
          </div>

          
      </div>

    </body>
</html>
