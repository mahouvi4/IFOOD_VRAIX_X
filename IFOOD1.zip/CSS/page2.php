<?php
    header("Refresh:10; url=menuvertical.php");
?>
<!DOCTYPE html>
<html>
    <head>
        <title>PAGE ACEUILLE 1</title>
        <meta charset="UTF -8">
        <link rel="stylesheet" href="stylepage.css">

        <style>
             h1{
             text-align: center;
             color:#fff ;
             font-family: "Brush Script MT", Times, serif;
             font-size: 5em;
             height: 600px;


         }

         .cube{
             margin-left: -900px;
             margin-top: 150px;
         }
        </style>
    </head>
    <body>
       
           
    <marquee scrollamount=20><h1>Bienvenu Chez Manu_Platium!!</h1></marquee>
           
      
        <div class="cube">
            <div class="top"></div>
            <div>
                <span style="--i:0;"></span>
                <span style="--i:1;"></span>
                <span style="--i:2;"></span>
                <span style="--i:3;"></span>
            </div>
        </div>

    </body>
</html>