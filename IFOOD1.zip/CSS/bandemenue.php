<!DOCTYPE html>
<html>
    <head>
        <title>PROFIL CLIENT</title>
        <meta charset="UTF -8">
        <link rel="stylesheet"  href="stymo.css">
        
    </head>
    <body>
        <div class="conatainer">

        <div class="zombi">
            <div class="serviceBox">
                <div class="icon" style="--i:#4eb7ff"><ion-icon name="color-palette-outline"></ion-icon></div>
                    <div class="content">
                        <h2>Design</h2>
                        <p>salut j'ai aimé le cours!!</p>
                
                    </div>
                        </div>

                        <div class="serviceBox">
                <div class="icon" style="--i:#fd6494"><ion-icon name="code-outline"></ion-icon></div>
                    <div class="content"></div>
                        </div>

                        <div class="serviceBox">
                <div class="icon" style="--i:#43f390"><ion-icon name="search-outline"></ion-icon></div>
                    <div class="content"></div>
                        </div>
                            
                        <div class="serviceBox">
                <div class="icon" style="--i:#ffb508"><ion-icon name="bar-chart-outline"></ion-icon></div>
                    <div class="content"></div>
                        </div>

                        <div class="serviceBox">
                <div class="icon" style="--i:#37ba82"><ion-icon name="videocam-outline"></ion-icon></div>
                    <div class="content"></div>
                        </div>

                        <div class="serviceBox">
                <div class="icon" style="--i:#cd57ff"><ion-icon name="game-controller-outline"></ion-icon></div>
                    <div class="content"></div>
                        </div>

     
            </div>
         </div>
         <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    </body>
</html>