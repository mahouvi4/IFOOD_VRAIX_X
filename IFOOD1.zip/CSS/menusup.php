<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>menu super</title>
        <link rel="stylesheet" href="superpo.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <div class="menu-bar">
        <ul>
            <li class="active"><a href="#">home</a><i class="fa fa-home" aria-hidden="true"></i></li>
            <li><a href="#">about us</a><i class="fa fa-user" aria-hidden="true"></i>
              <div class="sub-menu-1">
                 <ul>
                     <li><a href="#">Mission</a></li>
                     <li><a href="#">Vision</a></li>
                     <li><a href="#">Team</a></li>

                 </ul>
              </div>
        
        </li>
            <li><a href="#">service</a><i class="fa fa-clone" aria-hidden="true"></i>
            <div class="sub-menu-1">
                 <ul>
                     <li><a href="#">Web disign</a></li>

                     <li class="hover-me"><a href="#">Marketing</a><i class="fa fa-angle-right"></i>
                     <div class="sub-menu-2">
                    <ul>
                          <li><a href="#">SEO</a></li>
                          <li><a href="#">SOCIAL MEDIA</a></li>
                          <li><a href="#">APP</a></li>

                     </ul>
                    </div>
                    </li>

                    
                    <li class="hover-me"><a href="#">Mobile app</a><i class="fa fa-angle-right"></i>
                    <div class="sub-menu-2">
                    <ul>
                          <li><a href="#">android app</a></li>
                          <li><a href="#">ios app</a></li>
                          <li><a href="#">ionic APP</a></li>
                          <li><a href="#">ionic APP</a></li>
                    </ul>
                    </div>
                    </li>


                 </ul>
              </div>
        
        </li>


            <li><a href="#">client</a><i class="fa fa-users" aria-hidden="true"></i></li>
            <li><a href="#">contact</a><i class="fa fa-angellist" aria-hidden="true"></i></li>
            <li><a href="#">triof</a><i class="fa fa-inr" aria-hidden="true"></i></li>
            <li><a href="#">classment</a><i class="fa fa-edit" aria-hidden="true"></i></li>           
            <li><a href="#">casment</a><i class="fa fa-phone" aria-hidden="true"></i></li>
        </ul>
        </div>
    </body>
</html>